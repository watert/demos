/* model.js */
define(["app/base","underscore","backbone"],function(app,_,Backbone){
	var vars = {key:"value"};
	var Model = Backbone.Model.extend({
		initialize:function(){
			// Something
		}
	});
	return Model;
});