require(["config.js","app/base"],function(c,app){
    console.log(app);
});
